chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message.type!=='open-tabbi')return;
 (async()=>{
  if(Number.isInteger(message.windowId))await chrome.storage.session.set({tabbiSourceWindow:message.windowId});
  const base=chrome.runtime.getURL('app/index.html');
  const existing=(await chrome.tabs.query({})).find(t=>t.url?.startsWith(base));
  if(existing){await chrome.tabs.update(existing.id,{active:true,url:base+(message.view==='home'?'?view=home':'')});await chrome.windows.update(existing.windowId,{focused:true});}
  else await chrome.windows.create({url:base+(message.view==='home'?'?view=home':''),type:'normal',width:1180,height:900});
  reply({ok:true});
 })().catch(()=>reply({ok:false}));
 return true;
});

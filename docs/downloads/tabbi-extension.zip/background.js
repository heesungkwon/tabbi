chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message.type!=='open-tabbi')return;
 (async()=>{
  const windowId=Number.isInteger(message.windowId)?message.windowId:(await chrome.windows.getCurrent()).id;
  await chrome.storage.session.set({tabbiSourceWindow:windowId});
  const base=chrome.runtime.getURL('app/index.html');
  const params=new URLSearchParams({view:message.view==='home'?'home':'chat'});
  if(message.view==='home'){params.set('organize','1');params.set('goal',String(message.goal||'').slice(0,700));}
  const url=`${base}?${params}`;
  const existing=(await chrome.tabs.query({windowId})).find(t=>t.url?.startsWith(base));
  const tab=existing?await chrome.tabs.update(existing.id,{url,pinned:true,active:true}):await chrome.tabs.create({windowId,url,pinned:true,active:true,index:0});
  await chrome.tabs.move(tab.id,{index:0});
  reply({ok:true});
 })().catch(()=>reply({ok:false}));
 return true;
});

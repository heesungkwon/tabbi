chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message.type!=='open-tabbi')return;
 (async()=>{
  const windowId=Number.isInteger(message.windowId)?message.windowId:(await chrome.windows.getCurrent()).id;
  await chrome.storage.session.set({tabbiSourceWindow:windowId});
  const base=chrome.runtime.getURL('app/index.html');
  if(message.view==='home'){
   const params=new URLSearchParams({view:'home',organize:'1',goal:String(message.goal||'').slice(0,700)});
   await chrome.tabs.create({windowId,url:`${base}?${params}`,active:true});
  }else{
   await chrome.windows.create({url:`${base}?view=chat`,type:'normal',width:1180,height:900});
  }
  reply({ok:true});
 })().catch(()=>reply({ok:false}));
 return true;
});

import {cleanTabs,makeTask} from './app/engine.mjs';
import {closeVerifiedTabs} from './app/adapter.mjs';
const source=await chrome.windows.getCurrent();
const tabs=await chrome.tabs.query({windowId:source.id});
document.querySelector('#count').textContent=`${cleanTabs(tabs).length}개 탭을 정리할 수 있어요`;
for(const [id,view]of [['organize','home'],['find','chat']])document.getElementById(id).onclick=async()=>{const r=await chrome.runtime.sendMessage({type:'open-tabbi',windowId:source.id,view});if(r?.ok)window.close();else document.querySelector('#status').textContent='창을 열지 못했어요. 다시 시도해주세요.';};
for(const group of await chrome.tabGroups.query({windowId:source.id})){
 if(!/^태비|TABBI|DASI|탭하나/.test(group.title||''))continue;
 await chrome.tabGroups.update(group.id,{title:(group.title||'').replace(/^DASI|^탭하나/,'태비'),color:'blue'});
 const row=document.createElement('div');row.className='group';const label=document.createElement('span');label.textContent=(group.title||'찾은 탭').replace(/^DASI|^탭하나/,'태비');
 const small=document.createElement('small');small.textContent='저장한 뒤 그룹 전체 닫기';label.append(small);row.append(label);
 const close=document.createElement('button');close.textContent='×';close.title='이 그룹 저장하고 전체 닫기';close.setAttribute('aria-label',`${label.firstChild.textContent} 그룹 전체 닫기`);row.append(close);document.querySelector('#groups').append(row);
 close.onclick=async()=>{close.disabled=true;try{
  const live=await chrome.tabs.query({groupId:group.id});const safe=cleanTabs(live.map(t=>({id:`chrome-${t.id}`,browserId:t.id,title:t.title,url:t.url})));
  const state=(await chrome.storage.local.get('dasi')).dasi||{version:1,lang:'ko',tasks:[],tabs:[],events:[],chat:[],settings:{ai:true}};
  const task=makeTask({title:group.title.replace(/^DASI|^탭하나/,'태비'),purpose:'복원한 작업',tabIds:safe.map(t=>t.id)},safe);state.tasks.unshift(task);
  await chrome.storage.local.set({dasi:state});
  const r=await closeVerifiedTabs(safe);document.querySelector('#status').textContent=`${r.closed}개 탭을 저장하고 닫았어요${r.skipped?`. 고정·재생 중인 ${r.skipped}개는 남겼어요`:''}.`;
  if(!r.skipped)row.remove();else close.disabled=false;
 }catch{document.querySelector('#status').textContent='저장하지 못해 탭을 그대로 두었어요.';close.disabled=false;}};
}
